package it.vfsfitvnm.compose.persist

interface PersistMapOwner {
    val persistMap: PersistMap
}
